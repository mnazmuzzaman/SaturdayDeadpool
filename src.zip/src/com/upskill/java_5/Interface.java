package com.upskill.java_5;

public interface Interface {
	//Interface can have only abstract methods,java 8 and forward they have static method too
	//Abstract method do not have any implementation
	

public abstract void iDoor();





public abstract int iBus();

	
	
	 public  abstract String iTruck();
		
	 }

