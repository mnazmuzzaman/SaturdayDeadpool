package com.upskill.java_5;

public class DeadpoolException {
	
	String a;
	
	
	public DeadpoolException(String b){
		a=b;
	}
	

}
