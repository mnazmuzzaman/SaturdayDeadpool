package com.upskill.java_5;

    public class AbstractClassImplementation extends AbstractClass {
	@Override
	public void iDoor(){
		System.out.println("My car has 2 door !");
	}
	
	@Override public int iTruck(){
		return 10;
	}
	
	
     @Override
     public String iBus(){
	 return "Grayhond";
	 
 }
    }
