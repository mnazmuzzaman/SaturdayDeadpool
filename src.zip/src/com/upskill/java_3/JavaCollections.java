package com.upskill.java_3;

public class JavaCollections {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
