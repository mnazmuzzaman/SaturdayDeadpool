package com.upskill.java_2;

public class SwitchCase {
	public static void main(String[] args){
		int day =3;
		switch(day){
		case 1:
			System.out.println("monday");
			break;
		case 2:
			System.out.println("tuesday");
			break;
		case 3:
			System.out.println("wednesday");
		}
	}

}
