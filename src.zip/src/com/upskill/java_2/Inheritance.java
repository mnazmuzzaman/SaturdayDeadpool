package com.upskill.java_2;

public class Inheritance extends MethodType {

	/* The process of obtaining the data member and methods from one class to anther class is known as inheritance.
	 -Single Inheritance 
	 -Multiple Inheritance(Java doent support Multiple Inheritance 
	 */
	
	public static void main(String[] args){
		Inheritance obj = new Inheritance();
		obj.annualIncome();
		obj.weeklyIncome();
		System.out.println();
	}

}
