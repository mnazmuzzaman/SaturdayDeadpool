package com.upskill.java_6;

public class SingletonUse {
	
	public static void main (String[]args){
		
		Singleton Obj =Singleton.getInstance();
		
		Obj.demo();
		
	}

}
