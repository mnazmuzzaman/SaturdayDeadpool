package com.upskill.java_2;

import com.upskill.java_2.string;

public class SwitchCase {
	public static void main (string[] args){
		int day =3;
		switch(day){
		case 1:
			System.out.println("monday");
			break;
		case 2:
			System.out.println("tuesday");
			break;
		case 3:
			System.out.println("wednesday");
		}
	}

}

