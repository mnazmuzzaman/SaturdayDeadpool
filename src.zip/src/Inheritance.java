
public class Inheritance {

}
